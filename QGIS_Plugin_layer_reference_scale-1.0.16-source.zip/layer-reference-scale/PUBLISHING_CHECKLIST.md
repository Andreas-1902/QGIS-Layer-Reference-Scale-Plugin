# Publishing checklist

- Version: 1.0.16
- Critical Bandit finding `try/except/pass` in plugin.py removed.
- Repository: https://github.com/Andreas-1902/QGIS-Layer-Reference-Scale-Plugin
- Tracker: https://github.com/Andreas-1902/QGIS-Layer-Reference-Scale-Plugin/issues
- Push this source version to GitHub before/with the QGIS plugin upload.
