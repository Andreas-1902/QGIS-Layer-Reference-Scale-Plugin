# Layer Reference Scale

QGIS plugin for setting or resetting the symbology reference scale of multiple vector layers at once.

## Features

- Project layer tree including groups and subgroups.
- Native QGIS geometry icons for vector layers.
- Supported layers selected by default.
- Unsupported layers remain visible but disabled.
- Default scale: **1:50,000**.
- Preset, current map scale, or custom scale.
- Separate **Reset reference scale** checkbox.
- **Apply** button applies changes without closing the dialog.
- Non-modal always-on-top dialog: the QGIS map remains pannable and zoomable while the plugin is open.
- Plugin header with icon and short description.
- Toolbar tooltip and access via the QGIS Plugins menu.
- English/German user interface.
- Transparent plugin icon with centered white `R`.

## License

GPL-2.0-or-later.
