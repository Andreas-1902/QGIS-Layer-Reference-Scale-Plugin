Replace YOUR_GITHUB_USERNAME in metadata.txt before publication and ensure homepage/repository/tracker URLs are public.
