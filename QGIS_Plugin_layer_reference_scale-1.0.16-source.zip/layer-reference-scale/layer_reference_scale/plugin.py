# SPDX-License-Identifier: GPL-2.0-or-later
"""Bulk set or reset renderer reference scales for selected QGIS layers."""

import os

from qgis.PyQt.QtCore import Qt, QLocale
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtWidgets import (
    QAction,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsApplication,
    QgsLayerItem,
    QgsLayerTreeGroup,
    QgsLayerTreeLayer,
    QgsProject,
    QgsVectorLayer,
)

ROLE_LAYER_ID = Qt.UserRole + 1
ROLE_IS_GROUP = Qt.UserRole + 2

DE = {
    "Layer Reference Scale": "Referenzmaßstab für Layer",
    "Set layer reference scale…": "Referenzmaßstab für Layer setzen …",
    "Set or reset the symbology reference scale for selected layers":
        "Für ausgewählte Layer den Symbologie-Referenzmaßstab setzen oder zurücksetzen.",
    "Select layers. Unsupported layers remain visible but cannot be selected.":
        "Layer auswählen. Nicht unterstützte Layer bleiben sichtbar, können aber nicht ausgewählt werden.",
    "Layers and groups": "Layer / Gruppe",
    "Reference scale": "Referenzmaßstab",
    "Custom scale:": "Eigener Maßstab:",
    "Current map scale ({})": "Aktueller Kartenmaßstab ({})",
    "Custom scale…": "Eigener Maßstab …",
    "Reset reference scale": "Referenzmaßstab zurücksetzen",
    "Sets the symbology reference scale to 'no scale'.":
        "Setzt den Symbologie-Referenzmaßstab auf „Kein Maßstab“.",
    "This group contains no selectable layers.": "Diese Gruppe enthält keine wählbaren Layer.",
    "Reference scale can be set or reset.": "Referenzmaßstab kann gesetzt oder zurückgesetzt werden.",
    "Not selectable: no supported feature renderer.":
        "Nicht wählbar: kein unterstützter Feature-Renderer.",
    "{} of {} supported layers selected.": "{} von {} unterstützten Layern ausgewählt.",
    "No layers selected": "Keine Layer ausgewählt",
    "Please select at least one supported layer.": "Bitte mindestens einen unterstützten Layer auswählen.",
    "No layers are loaded in the current project.": "Im aktuellen Projekt sind keine Layer geladen.",
    "Reference Scale": "Referenzmaßstab",
    "Reference scale was reset for {} layer(s).": "Der Referenzmaßstab wurde für {} Layer zurückgesetzt.",
    "Reference scale {} was set for {} layer(s).": "Referenzmaßstab {} wurde für {} Layer gesetzt.",
    "{} layer(s) could not be changed.": "{} Layer konnten nicht geändert werden.",
    "Apply": "Anwenden",
    "OK": "OK",
    "Cancel": "Abbrechen",
    "Layer Reference Scale menu": "Layer-Referenzmaßstab",
    "Applied successfully.": "Erfolgreich angewendet.",
    "Expand all": "Alles ausklappen",
    "Collapse all": "Alles einklappen",
}


def tr(text):
    if QLocale.system().name().lower().startswith("de"):
        return DE.get(text, text)
    return text


class ReferenceScaleDialog(QDialog):
    PRESETS = [
        100, 200, 250, 500, 750, 1000, 1500, 2000, 2500, 5000,
        7500, 10000, 15000, 20000, 25000, 50000, 100000, 250000,
        500000, 1000000,
    ]

    def __init__(self, iface, apply_callback, icon_path, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.apply_callback = apply_callback
        self.project = QgsProject.instance()
        self.current_scale = max(1.0, float(iface.mapCanvas().scale()))
        self._updating = False

        self.setWindowTitle(tr("Layer Reference Scale"))
        self.setWindowIcon(QIcon(icon_path))
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.resize(690, 760)

        main = QVBoxLayout(self)
        main.setSpacing(10)

        # Header: plugin icon + title + description.
        header = QHBoxLayout()
        logo = QLabel()
        pix = QPixmap(icon_path)
        logo.setPixmap(pix.scaled(62, 62, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setFixedSize(72, 72)
        logo.setAlignment(Qt.AlignCenter)
        header.addWidget(logo)

        head_text = QVBoxLayout()
        title = QLabel("<b>{}</b>".format(tr("Layer Reference Scale")))
        title_font = title.font()
        title_font.setPointSize(title_font.pointSize() + 3)
        title.setFont(title_font)
        head_text.addWidget(title)

        desc = QLabel(tr("Set or reset the symbology reference scale for selected layers"))
        desc.setWordWrap(True)
        head_text.addWidget(desc)
        head_text.addStretch(1)
        header.addLayout(head_text, 1)
        main.addLayout(header)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main.addWidget(line)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabel(tr("Layers and groups"))
        self.tree.setAlternatingRowColors(True)
        self.tree.setIconSize(self.tree.iconSize())
        self.tree.itemChanged.connect(self._item_changed)

        tree_tools = QHBoxLayout()
        tree_tools.setContentsMargins(0, 0, 0, 0)
        tree_tools.setSpacing(4)

        self.expand_all_button = QToolButton()
        self.expand_all_button.setToolTip(tr("Expand all"))
        self.expand_all_button.setAutoRaise(True)
        self.expand_all_button.setIcon(
            QgsApplication.getThemeIcon("/mActionExpandTree.svg")
        )
        self.expand_all_button.clicked.connect(self.tree.expandAll)
        tree_tools.addWidget(self.expand_all_button)

        self.collapse_all_button = QToolButton()
        self.collapse_all_button.setToolTip(tr("Collapse all"))
        self.collapse_all_button.setAutoRaise(True)
        self.collapse_all_button.setIcon(
            QgsApplication.getThemeIcon("/mActionCollapseTree.svg")
        )
        self.collapse_all_button.clicked.connect(self.tree.collapseAll)
        tree_tools.addWidget(self.collapse_all_button)

        tree_tools.addStretch(1)
        main.addLayout(tree_tools)
        main.addWidget(self.tree, 1)
        self._build_tree()

        # Reference-scale controls.
        scale_box = QFrame()
        scale_box.setFrameShape(QFrame.StyledPanel)
        scale_layout = QVBoxLayout(scale_box)

        scale_title = QLabel("<b>{}</b>".format(tr("Reference scale")))
        scale_layout.addWidget(scale_title)

        form_widget = QWidget()
        form = QFormLayout(form_widget)
        form.setContentsMargins(0, 0, 0, 0)

        self.combo = QComboBox()
        for scale in self.PRESETS:
            self.combo.addItem(self._format_scale(scale), float(scale))
        self.combo.addItem(
            tr("Current map scale ({})").format(self._format_scale(self.current_scale)),
            "CURRENT",
        )
        self.combo.addItem(tr("Custom scale…"), "CUSTOM")

        # Requested default: 1:50,000
        index_50000 = self.combo.findData(50000.0)
        if index_50000 >= 0:
            self.combo.setCurrentIndex(index_50000)
        self.combo.currentIndexChanged.connect(self._scale_mode_changed)

        self.custom = QDoubleSpinBox()
        self.custom.setRange(1.0, 1000000000000.0)
        self.custom.setDecimals(0)
        self.custom.setSingleStep(1000.0)
        self.custom.setValue(50000.0)
        self.custom.setPrefix("1:")
        self.custom.setGroupSeparatorShown(True)
        self.custom.setVisible(False)

        form.addRow(tr("Reference scale") + ":", self.combo)
        form.addRow(tr("Custom scale:"), self.custom)
        scale_layout.addWidget(form_widget)

        self.reset_check = QCheckBox(tr("Reset reference scale"))
        self.reset_check.setToolTip(tr("Sets the symbology reference scale to 'no scale'."))
        self.reset_check.toggled.connect(self._reset_toggled)
        scale_layout.addWidget(self.reset_check)

        reset_info = QLabel(tr("Sets the symbology reference scale to 'no scale'."))
        reset_info.setWordWrap(True)
        reset_info.setStyleSheet("color: palette(mid);")
        scale_layout.addWidget(reset_info)

        main.addWidget(scale_box)

        self.status = QLabel()
        main.addWidget(self.status)
        self._update_status()

        # Bottom buttons:
        # Apply = apply and keep dialog open
        # OK = apply and close on success
        # Cancel = close without applying
        buttons = QHBoxLayout()
        buttons.addStretch(1)

        self.apply_button = QPushButton(tr("Apply"))
        self.apply_button.clicked.connect(self._apply)
        buttons.addWidget(self.apply_button)

        self.ok_button = QPushButton(tr("OK"))
        self.ok_button.setDefault(True)
        self.ok_button.clicked.connect(self._ok)
        buttons.addWidget(self.ok_button)

        cancel_button = QPushButton(tr("Cancel"))
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(cancel_button)
        main.addLayout(buttons)

    @staticmethod
    def _format_scale(scale):
        return "1:{:,.0f}".format(scale).replace(",", ".")

    @staticmethod
    def _supported(layer):
        return (
            isinstance(layer, QgsVectorLayer)
            and layer.renderer() is not None
            and hasattr(layer.renderer(), "setReferenceScale")
        )

    @staticmethod
    def _layer_icon(layer):
        if isinstance(layer, QgsVectorLayer):
            try:
                return QgsLayerItem.iconForWkbType(layer.wkbType())
            except Exception:
                return QIcon()
        return QIcon()

    def _build_tree(self):
        self._updating = True
        self.tree.clear()
        root = self.project.layerTreeRoot()

        for node in root.children():
            self._add_node(node, self.tree.invisibleRootItem())

        for i in range(self.tree.topLevelItemCount()):
            self._refresh_recursive(self.tree.topLevelItem(i))

        self.tree.expandAll()
        self._collapse_unsupported_only_groups()
        self._updating = False

    def _add_node(self, node, parent):
        if isinstance(node, QgsLayerTreeGroup):
            item = QTreeWidgetItem(parent, [node.name()])
            item.setData(0, ROLE_IS_GROUP, True)
            item.setIcon(0, QgsApplication.getThemeIcon("/mIconFolder.svg"))
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)

            for child in node.children():
                self._add_node(child, item)

            if self._group_has_supported(item):
                item.setCheckState(0, Qt.Checked)
            else:
                item.setCheckState(0, Qt.Unchecked)
                item.setFlags(item.flags() & ~Qt.ItemIsEnabled)
                item.setToolTip(0, tr("This group contains no selectable layers."))
            return

        if isinstance(node, QgsLayerTreeLayer):
            layer = node.layer()
            item = QTreeWidgetItem(parent, [node.name()])
            item.setData(0, ROLE_IS_GROUP, False)

            if layer is not None:
                item.setData(0, ROLE_LAYER_ID, layer.id())
                icon = self._layer_icon(layer)
                if not icon.isNull():
                    item.setIcon(0, icon)

            item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsSelectable)

            if layer is not None and self._supported(layer):
                item.setFlags(item.flags() | Qt.ItemIsEnabled)
                item.setCheckState(0, Qt.Checked)
                item.setToolTip(0, tr("Reference scale can be set or reset."))
            else:
                item.setFlags(item.flags() & ~Qt.ItemIsEnabled)
                item.setCheckState(0, Qt.Unchecked)
                item.setToolTip(0, tr("Not selectable: no supported feature renderer."))

    def _group_has_supported(self, item):
        for i in range(item.childCount()):
            child = item.child(i)
            if child.data(0, ROLE_IS_GROUP):
                if self._group_has_supported(child):
                    return True
            elif child.flags() & Qt.ItemIsEnabled:
                return True
        return False

    def _set_descendants(self, item, state):
        for i in range(item.childCount()):
            child = item.child(i)
            if child.data(0, ROLE_IS_GROUP):
                if child.flags() & Qt.ItemIsEnabled:
                    child.setCheckState(0, state)
                    self._set_descendants(child, state)
            elif child.flags() & Qt.ItemIsEnabled:
                child.setCheckState(0, state)

    def _refresh_group(self, item):
        states = [
            item.child(i).checkState(0)
            for i in range(item.childCount())
            if item.child(i).flags() & Qt.ItemIsEnabled
        ]
        if not states or all(state == Qt.Unchecked for state in states):
            item.setCheckState(0, Qt.Unchecked)
        elif all(state == Qt.Checked for state in states):
            item.setCheckState(0, Qt.Checked)
        else:
            item.setCheckState(0, Qt.PartiallyChecked)

    def _refresh_recursive(self, item):
        if not item.data(0, ROLE_IS_GROUP):
            return
        for i in range(item.childCount()):
            child = item.child(i)
            if child.data(0, ROLE_IS_GROUP):
                self._refresh_recursive(child)
        self._refresh_group(item)

    def _refresh_parents(self, item):
        parent = item.parent()
        while parent is not None:
            if parent.data(0, ROLE_IS_GROUP):
                self._refresh_group(parent)
            parent = parent.parent()

    def _item_changed(self, item, column):
        if self._updating or column != 0:
            return
        self._updating = True
        try:
            if item.data(0, ROLE_IS_GROUP):
                state = item.checkState(0)
                if state in (Qt.Checked, Qt.Unchecked):
                    self._set_descendants(item, state)
            self._refresh_parents(item)
            self._update_status()
        finally:
            self._updating = False

    def _items(self, parent=None):
        parent = parent or self.tree.invisibleRootItem()
        for i in range(parent.childCount()):
            child = parent.child(i)
            yield child
            yield from self._items(child)


    def _collapse_unsupported_only_groups(self):
        """Collapse groups that contain no supported layer descendants."""
        root = self.tree.invisibleRootItem()

        def apply_state(item):
            if not item.data(0, ROLE_IS_GROUP):
                return

            # A group is useful if it contains at least one supported layer,
            # directly or in any nested subgroup.
            has_supported = self._group_has_supported(item)
            item.setExpanded(has_supported)

            for i in range(item.childCount()):
                child = item.child(i)
                if child.data(0, ROLE_IS_GROUP):
                    apply_state(child)

        for i in range(root.childCount()):
            item = root.child(i)
            if item.data(0, ROLE_IS_GROUP):
                apply_state(item)

    def selected_layer_ids(self):
        return [
            item.data(0, ROLE_LAYER_ID)
            for item in self._items()
            if (
                not item.data(0, ROLE_IS_GROUP)
                and item.data(0, ROLE_LAYER_ID)
                and (item.flags() & Qt.ItemIsEnabled)
                and item.checkState(0) == Qt.Checked
            )
        ]

    def supported_count(self):
        return sum(
            1
            for item in self._items()
            if not item.data(0, ROLE_IS_GROUP) and (item.flags() & Qt.ItemIsEnabled)
        )

    def _update_status(self):
        self.status.setText(
            tr("{} of {} supported layers selected.").format(
                len(self.selected_layer_ids()), self.supported_count()
            )
        )

    def _scale_mode_changed(self):
        self.custom.setVisible(self.combo.currentData() == "CUSTOM")

    def _reset_toggled(self, checked):
        self.combo.setEnabled(not checked)
        self.custom.setEnabled(not checked)
        if not checked:
            self._scale_mode_changed()

    def selected_scale(self):
        if self.reset_check.isChecked():
            return -1.0
        data = self.combo.currentData()
        if data == "CURRENT":
            return self.current_scale
        if data == "CUSTOM":
            return float(self.custom.value())
        return float(data)

    def is_reset_mode(self):
        return self.reset_check.isChecked()

    def _apply_changes(self):
        if not self.selected_layer_ids():
            QMessageBox.warning(
                self,
                tr("No layers selected"),
                tr("Please select at least one supported layer."),
            )
            return False

        ok, message = self.apply_callback(
            self.selected_layer_ids(),
            self.selected_scale(),
            self.is_reset_mode(),
        )
        if ok:
            self.status.setText(message)
            return True

        QMessageBox.warning(self, tr("Reference Scale"), message)
        return False

    def _apply(self):
        self._apply_changes()

    def _ok(self):
        if self._apply_changes():
            self.accept()


class LayerReferenceScalePlugin:
    MENU_TEXT_EN = "&Layer Reference Scale"
    MENU_TEXT_DE = "&Layer-Referenzmaßstab"

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.toolbar = None
        self.dialog = None
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "layer_reference_scale_icon.png")
        icon = QIcon(icon_path)
        self.action = QAction(
            icon,
            tr("Set layer reference scale…"),
            self.iface.mainWindow(),
        )

        tooltip = tr("Set or reset the symbology reference scale for selected layers")
        self.action.setToolTip(tooltip)
        self.action.setStatusTip(tooltip)
        self.action.triggered.connect(self.run)

        # Dedicated plugin toolbar instead of the generic Plugins toolbar.
        self.toolbar = self.iface.addToolBar("Layer Reference Scale")
        self.toolbar.setObjectName("LayerReferenceScaleToolbar")
        self.toolbar.setToolTip(tr("Layer Reference Scale"))
        self.toolbar.addAction(self.action)

        self.menu_text = (
            self.MENU_TEXT_DE
            if QLocale.system().name().lower().startswith("de")
            else self.MENU_TEXT_EN
        )
        self.iface.addPluginToMenu(self.menu_text, self.action)

    def unload(self):
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None

        if self.action:
            self.iface.removePluginMenu(self.menu_text, self.action)
            if self.toolbar is not None:
                self.toolbar.removeAction(self.action)
            self.action.deleteLater()
            self.action = None

        if self.toolbar is not None:
            self.toolbar.deleteLater()
            self.toolbar = None

    def _apply_reference_scale(self, layer_ids, scale, reset_mode):
        project = QgsProject.instance()
        changed = []
        failed = []

        for layer_id in layer_ids:
            layer = project.mapLayer(layer_id)
            if layer is None:
                failed.append(layer_id)
                continue

            try:
                renderer = layer.renderer()
                if renderer is None or not hasattr(renderer, "setReferenceScale"):
                    failed.append(layer.name())
                    continue
                renderer.setReferenceScale(scale)
                layer.triggerRepaint()
                changed.append(layer.name())
            except Exception as exc:
                failed.append(f"{layer.name()} ({exc})")

        if changed:
            project.setDirty(True)
            self.iface.mapCanvas().refresh()

        if reset_mode:
            message = tr("Reference scale was reset for {} layer(s).").format(len(changed))
        else:
            formatted = "1:{:,.0f}".format(scale).replace(",", ".")
            message = tr("Reference scale {} was set for {} layer(s).").format(
                formatted, len(changed)
            )

        if failed:
            message += " " + tr("{} layer(s) could not be changed.").format(len(failed))

        return (bool(changed), message)

    def run(self):
        project = QgsProject.instance()
        if not project.mapLayers():
            QMessageBox.information(
                self.iface.mainWindow(),
                tr("Reference Scale"),
                tr("No layers are loaded in the current project."),
            )
            return

        # Reuse the existing non-modal dialog instead of opening duplicates.
        if self.dialog is not None:
            self.dialog.show()
            self.dialog.raise_()
            self.dialog.activateWindow()
            return

        icon_path = os.path.join(self.plugin_dir, "layer_reference_scale_icon.png")
        self.dialog = ReferenceScaleDialog(
            self.iface,
            self._apply_reference_scale,
            icon_path,
            self.iface.mainWindow(),
        )
        self.dialog.setAttribute(Qt.WA_DeleteOnClose, True)
        self.dialog.destroyed.connect(self._dialog_destroyed)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def _dialog_destroyed(self, *args):
        self.dialog = None
